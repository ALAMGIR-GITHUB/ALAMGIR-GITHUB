/**
 * @(#)RSA_FINAL.java
 *
 * RSA_FINAL application
 *
 * @author ALAMGIR SARDAR
 * @version 1.00 2022/3/4
 */
 
package me.faolou.util;
import java.util.Scanner;



/*************************************************************************
 *  Compilation:  javac RSA.java
 *  Execution:    java RSA N
 *
 *  Generate an N-bit public and private RSA key and use to encrypt
 *  and decrypt a random message.
 *
 *
 *************************************************************************/

import java.math.BigInteger;
import java.security.SecureRandom;


public class RSA_FINAL {
    private final static BigInteger one      = new BigInteger("1");
    private final static SecureRandom random = new SecureRandom();

    private BigInteger privateKey;
    private BigInteger publicKey;
    private BigInteger modulus;
    static int total_values;
    


    // generate an N-bit (roughly) public and private key
    RSA_FINAL(int N) {
        BigInteger p = BigInteger.probablePrime(N/2, random);
        BigInteger q = BigInteger.probablePrime(N/2, random);
        BigInteger r = BigInteger.probablePrime(N/2, random);
        BigInteger s = BigInteger.probablePrime(N/2, random);
        BigInteger phi = (p.subtract(one)).multiply(q.subtract(one)).multiply(r.subtract(one)).multiply(s.subtract(one));

        modulus    = p.multiply(q).multiply(r).multiply(s);
        //publicKey  = new BigInteger("997");     // common value in practice = 2^16 + 1
         publicKey  =BigInteger.probablePrime(N/4, random);
        privateKey = publicKey.modInverse(phi);
    }


    BigInteger[] encrypt(BigInteger[] message) {
    	BigInteger encrypted_msg[]=new BigInteger[total_values];
    	for(int i=0;i<total_values;i++)
    	{
    		encrypted_msg[i]=message[i].modPow(publicKey, modulus);
    	}
        //return message.modPow(publicKey, modulus);
        return encrypted_msg;
    }

    BigInteger[] decrypt(BigInteger[] encrypted) {
        //return encrypted.modPow(privateKey, modulus);
        BigInteger decrypted_msg[]=new BigInteger[total_values];
    	for(int i=0;i<total_values;i++)
    	{
    		decrypted_msg[i]=encrypted[i].modPow(privateKey, modulus);
    	}
        //return message.modPow(publicKey, modulus);
        return decrypted_msg;
    }
    

    public String toString() {
        String s = "";
        s += "public  = " + publicKey  + "\n";
        s += "private = " + privateKey + "\n";
        s += "modulus = " + modulus;
        return s;
    }

    public static void main(String[] args) {
    	Scanner in =new  Scanner(System.in);
    	
    	System.out.print("How many elements you want to encrypt?=");
    	total_values=in.nextInt();

    	System.out.print("Enter bit length=");
    	int N=in.nextInt();
        //int N = Integer.parseInt(arg[0]);
        
        long begin = System.currentTimeMillis();
        
        RSA_FINAL key = new RSA_FINAL(N);
        System.out.println(key);
        
        long end = System.currentTimeMillis();
        

        // create random message, encrypt and decrypt
        //BigInteger message = new BigInteger(N-1, random);
        
        BigInteger message[] = new BigInteger[total_values];
        for(int i=0;i<total_values;i++){        
        	//message[i] = new BigInteger((N-1), random);
        	message[i]=BigInteger.valueOf(i+999);
    	}
    	
    	System.out.println("\nOriginal message   = \n" );
    	for(int i=0;i<total_values;i++){ 
        System.out.print(message[i]+" ");
    	}

        //// create message by converting string to integer
        // String s = "test";
        // byte[] bytes = s.getBytes();
        // BigInteger message = new BigInteger(s);
        
        long begin1 = System.currentTimeMillis();
        BigInteger encrypt[] = key.encrypt(message);
        System.out.println("\nEncrypted message   = \n" );
        for(int i=0;i<total_values;i++){ 
        System.out.print(encrypt[i]+" ");
    	}
    	
        long end1 = System.currentTimeMillis();
        

        
        long begin2 = System.currentTimeMillis();
        System.out.println("\nDecrypted message   = \n" );
        BigInteger decrypt[] = key.decrypt(encrypt);
        for(int i=0;i<total_values;i++){  
        System.out.print(decrypt[i]+" ");
    	}
    	
        long end2 = System.currentTimeMillis();
        
        
        //System.out.println("message   = " + message);
        //System.out.println("encrpyted = " + encrypt);
        //System.out.println("decrypted = " + decrypt);
        
        long time1 = end-begin;
        System.out.println("\nElapsed Time for key generation: "+time1 +" milli seconds");
        
        long time2 = end1-begin1;
        System.out.println("Elapsed Time for encryption: "+time2 +" milli seconds");
        
		long time3 = end2-begin2;
        System.out.println("Elapsed Time for decryption: "+time3 +" milli seconds");
    }
}